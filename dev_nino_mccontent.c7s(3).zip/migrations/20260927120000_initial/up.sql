ALTER TABLE servers ADD COLUMN content_install_limit INTEGER NOT NULL DEFAULT 0;

CREATE TABLE dev_nino_mccontent_installed (
    uuid uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    server_uuid uuid NOT NULL REFERENCES servers(uuid) ON DELETE CASCADE,
    source VARCHAR(31) NOT NULL,
    project_id VARCHAR(128) NOT NULL,
    project_slug VARCHAR(255) NOT NULL,
    project_name VARCHAR(255) NOT NULL,
    kind VARCHAR(16) NOT NULL,
    version_id VARCHAR(128) NOT NULL,
    version_number VARCHAR(128) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    file_path VARCHAR(512) NOT NULL,
    size_bytes BIGINT NOT NULL DEFAULT 0,
    installed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (server_uuid, source, project_id)
);

CREATE INDEX dev_nino_mccontent_installed_server_uuid_idx
    ON dev_nino_mccontent_installed (server_uuid);

CREATE INDEX dev_nino_mccontent_installed_kind_idx
    ON dev_nino_mccontent_installed (kind);
