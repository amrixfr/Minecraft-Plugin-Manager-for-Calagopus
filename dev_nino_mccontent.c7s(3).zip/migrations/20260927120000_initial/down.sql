DROP TABLE IF EXISTS dev_nino_mccontent_installed;
ALTER TABLE servers DROP COLUMN IF EXISTS content_install_limit;
