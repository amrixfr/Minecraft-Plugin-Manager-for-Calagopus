export type ContentKind = "plugin" | "mod" | "modpack";

export interface ProjectSummary {
  id: string;
  slug: string;
  name: string;
  description: string;
  author: string;
  icon_url?: string | null;
  downloads: number;
  kind: ContentKind;
  source: string;
  loaders: string[];
  game_versions: string[];
}

export interface VersionInfo {
  id: string;
  name: string;
  version_number: string;
  game_versions: string[];
  loaders: string[];
  download_url: string;
  filename: string;
  size_bytes: number;
  release_type: string;
}

export interface InstalledContent {
  uuid: string;
  server_uuid: string;
  source: string;
  project_id: string;
  project_slug: string;
  project_name: string;
  kind: ContentKind;
  version_id: string;
  version_number: string;
  filename: string;
  file_path: string;
  size_bytes: number;
  installed_at: string;
  updated_at: string;
}

export interface ExtensionSettings {
  providers: {
    modrinth: boolean;
    curseforge: boolean;
    hangar: boolean;
    spigotmc: boolean;
    curseforge_api_key?: string | null;
  };
  max_download_bytes: number;
  blacklist: Array<
    | { kind: "project_id"; id: string }
    | { kind: "regex"; pattern: string }
  >;
  default_loaders: string[];
}
