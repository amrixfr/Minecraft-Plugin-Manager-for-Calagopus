import { ModalProps } from '@mantine/core';
import ConfirmationModal from '@/elements/modals/ConfirmationModal.tsx';
import Text from '@/elements/typography/Text.tsx';
import type { InstalledContent } from '../../../lib/schemas';

export default function ContentRemoveModal({
  content,
  onRemoved,
  ...props
}: Omit<ModalProps, 'children'> & {
  content: InstalledContent | null;
  onRemoved: (uuid: string) => void;
}) {
  return (
    <ConfirmationModal
      title='Remove content'
      confirmColor='red'
      confirmText='Remove'
      onConfirmed={() => {
        if (content) onRemoved(content.uuid);
      }}
      {...props}
    >
      {content && (
        <>
          <Text size='sm'>
            Are you sure you want to remove <strong>{content.project_name}</strong> (v
            {content.version_number})?
          </Text>
          <Text size='sm' c='dimmed' mt='xs'>
            The file <code>{content.file_path}</code> will be deleted from the server.
          </Text>
        </>
      )}
    </ConfirmationModal>
  );
}
