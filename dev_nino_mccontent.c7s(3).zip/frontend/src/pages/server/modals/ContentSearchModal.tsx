import { useState } from "react";
import type { ContentKind, ProjectSummary } from "../../../lib/schemas";

interface Props {
  serverUuid: string;
  onClose: () => void;
  onSelect: (project: ProjectSummary) => void;
}

export function ContentSearchModal({ serverUuid, onClose, onSelect }: Props) {
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState<ContentKind>("mod");
  const [results, setResults] = useState<ProjectSummary[]>([]);
  const [loading, setLoading] = useState(false);

  async function doSearch() {
    if (!query.trim()) return;
    setLoading(true);
    try {
      // Placeholder – real call: GET /servers/{uuid}/content/search?q=…&kind=…
      setResults([]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="modal-backdrop">
      <div className="modal max-w-2xl">
        <div className="modal-header">
          <h3>Search content</h3>
          <button onClick={onClose}>×</button>
        </div>
        <div className="modal-body space-y-4">
          <div className="flex gap-2">
            <select
              value={kind}
              onChange={(e) => setKind(e.target.value as ContentKind)}
              className="input"
            >
              <option value="plugin">Plugins</option>
              <option value="mod">Mods</option>
              <option value="modpack">Modpacks</option>
            </select>
            <input
              className="input flex-1"
              placeholder="Search…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && doSearch()}
            />
            <button className="btn btn-primary" onClick={doSearch} disabled={loading}>
              {loading ? "Searching…" : "Search"}
            </button>
          </div>

          <div className="max-h-96 overflow-y-auto space-y-2">
            {results.length === 0 && !loading && (
              <p className="text-sm text-muted-foreground text-center py-8">
                Enter a search term and press Search.
              </p>
            )}
            {results.map((p) => (
              <button
                key={`${p.source}-${p.id}`}
                className="w-full text-left rounded border p-3 hover:bg-muted"
                onClick={() => onSelect(p)}
              >
                <div className="font-medium">{p.name}</div>
                <div className="text-sm text-muted-foreground line-clamp-2">
                  {p.description}
                </div>
                <div className="text-xs mt-1">
                  {p.source} · {p.downloads.toLocaleString()} downloads
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
