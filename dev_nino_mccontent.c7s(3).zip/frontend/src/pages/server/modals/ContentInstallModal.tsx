import { ModalProps } from '@mantine/core';
import { useEffect, useState } from 'react';
import Button from '@/elements/buttons/Button.tsx';
import Select from '@/elements/input/Select.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import { Modal, ModalFooter } from '@/elements/modals/Modal.tsx';
import Text from '@/elements/typography/Text.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import {
  getProjectVersions,
  type ModrinthHit,
  type ModrinthVersion,
} from '../../../api/modrinth';

export default function ContentInstallModal({
  project,
  loader,
  gameVersion,
  onConfirm,
  ...props
}: ModalProps & {
  project: ModrinthHit | null;
  loader?: string | null;
  gameVersion?: string | null;
  onConfirm: (version: ModrinthVersion) => void;
}) {
  const { addToast } = useToast();
  const [versions, setVersions] = useState<ModrinthVersion[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!props.opened || !project) return;
    setLoading(true);
    setSelected(null);
    setVersions([]);
    getProjectVersions(project.project_id, loader, gameVersion)
      .then((v) => {
        setVersions(v);
        if (v[0]) setSelected(v[0].id);
      })
      .catch((err) =>
        addToast(err instanceof Error ? err.message : 'Failed to load versions', 'error'),
      )
      .finally(() => setLoading(false));
  }, [props.opened, project, loader, gameVersion, addToast]);

  const chosen = versions.find((v) => v.id === selected) ?? null;

  return (
    <Modal title={project ? `Install ${project.title}` : 'Install plugin'} {...props}>
      <Stack gap='md'>
        {project && (
          <Text size='sm' c='dimmed'>
            {project.description}
          </Text>
        )}
        <Select
          label='Version'
          description='Choose which version to download from Modrinth'
          placeholder={loading ? 'Loading versions…' : 'Select version'}
          data={versions.map((v) => ({
            value: v.id,
            label: `${v.version_number} · ${v.version_type}${
              v.game_versions?.length ? ` · MC ${v.game_versions.slice(0, 3).join(', ')}` : ''
            }${v.loaders?.length ? ` · ${v.loaders.join(', ')}` : ''}`,
          }))}
          value={selected}
          onChange={setSelected}
          disabled={loading}
          searchable
        />
        {chosen && (
          <Text size='xs' c='dimmed'>
            Will save to /home/container/plugins/
            {chosen.files.find((f) => f.primary)?.filename ?? chosen.files[0]?.filename ?? '…'}
          </Text>
        )}
      </Stack>
      <ModalFooter>
        <Button variant='default' onClick={props.onClose}>
          Cancel
        </Button>
        <Button
          color='blue'
          disabled={!chosen || loading}
          onClick={() => {
            if (chosen) onConfirm(chosen);
          }}
        >
          Download & Install
        </Button>
      </ModalFooter>
    </Modal>
  );
}
