import {
  faDownload,
  faExternalLink,
  faPuzzlePiece,
  faSearch,
  faSpinner,
  faTrash,
} from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Badge,
  Card,
  Group,
  Image,
  Loader,
  Progress,
  SimpleGrid,
  Text,
} from '@mantine/core';
import { useCallback, useEffect, useRef, useState } from 'react';
import Button from '@/elements/buttons/Button.tsx';
import Select from '@/elements/input/Select.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import ServerContentContainer from '@/elements/containers/ServerContentContainer.tsx';
import { useToast } from '@/providers/ToastProvider.tsx';
import { useServerStore } from '@/stores/server.ts';
import {
  getProjectVersions,
  primaryFile,
  searchModrinth,
  type ModrinthHit,
  type ModrinthVersion,
} from '../../api/modrinth';
import pullFileToServer from '../../api/server/installContent';
import type { InstalledContent } from '../../lib/schemas';
import ContentInstallModal from './modals/ContentInstallModal';
import ContentRemoveModal from './modals/ContentRemoveModal';

function formatDownloads(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

function ProjectCard({
  hit,
  installed,
  installing,
  progress,
  onInstall,
  onRemove,
}: {
  hit: ModrinthHit;
  installed: boolean;
  installing: boolean;
  progress: number | null;
  onInstall: () => void;
  onRemove: () => void;
}) {
  return (
    <Card
      padding='md'
      radius='md'
      withBorder
      style={{
        background: 'var(--mantine-color-dark-6)',
        borderColor: 'var(--mantine-color-dark-4)',
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {installing && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            background: 'rgba(0,0,0,0.55)',
            zIndex: 2,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 8,
            padding: 16,
          }}
        >
          <FontAwesomeIcon icon={faSpinner} spin size='lg' />
          <Text size='sm' fw={500}>
            Downloading to plugins/…
          </Text>
          {progress !== null && (
            <Progress value={progress} w='80%' size='sm' animated color='blue' />
          )}
        </div>
      )}

      <Group justify='space-between' align='flex-start' mb='xs' wrap='nowrap'>
        <Group gap='sm' wrap='nowrap' style={{ minWidth: 0 }}>
          <div
            style={{
              width: 48,
              height: 48,
              borderRadius: 10,
              background: 'var(--mantine-color-dark-5)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              overflow: 'hidden',
            }}
          >
            {hit.icon_url ? (
              <Image src={hit.icon_url} w={48} h={48} alt='' fit='cover' />
            ) : (
              <FontAwesomeIcon icon={faPuzzlePiece} style={{ opacity: 0.5 }} />
            )}
          </div>
          <div style={{ minWidth: 0 }}>
            <Group gap={6} wrap='nowrap'>
              <Text fw={600} size='sm' truncate>
                {hit.title}
              </Text>
              {installed && (
                <Badge size='xs' color='teal' variant='filled'>
                  INSTALLED
                </Badge>
              )}
            </Group>
            <Text size='xs' c='dimmed' truncate>
              By {hit.author}
            </Text>
            <Text size='xs' c='dimmed'>
              {formatDownloads(hit.downloads)} downloads
            </Text>
          </div>
        </Group>
        <Text
          component='a'
          href={`https://modrinth.com/plugin/${hit.slug}`}
          target='_blank'
          rel='noreferrer'
          c='dimmed'
          style={{ flexShrink: 0 }}
        >
          <FontAwesomeIcon icon={faExternalLink} size='sm' />
        </Text>
      </Group>

      <Text size='sm' c='dimmed' lineClamp={3} style={{ flex: 1, marginBottom: 12 }}>
        {hit.description}
      </Text>

      <Group gap='xs' justify='flex-end' mt='auto'>
        {installed ? (
          <Button
            color='red'
            variant='light'
            size='xs'
            leftSection={<FontAwesomeIcon icon={faTrash} />}
            onClick={onRemove}
            disabled={installing}
          >
            Delete
          </Button>
        ) : (
          <Button
            color='blue'
            size='xs'
            leftSection={<FontAwesomeIcon icon={faDownload} />}
            onClick={onInstall}
            disabled={installing}
          >
            Install
          </Button>
        )}
      </Group>
    </Card>
  );
}

export default function ServerContentPage() {
  const { server } = useServerStore();
  const { addToast } = useToast();

  const [query, setQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [mcVersion, setMcVersion] = useState<string | null>(null);
  const [loader, setLoader] = useState<string | null>(null);
  const [sort, setSort] = useState<string | null>('downloads');

  const [hits, setHits] = useState<ModrinthHit[]>([]);
  const [total, setTotal] = useState(0);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [installed, setInstalled] = useState<InstalledContent[]>([]);
  const [installingId, setInstallingId] = useState<string | null>(null);
  const [progress, setProgress] = useState<number | null>(null);
  const [installTarget, setInstallTarget] = useState<ModrinthHit | null>(null);
  const [removeTarget, setRemoveTarget] = useState<InstalledContent | null>(null);

  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const loadingRef = useRef(false);
  const limit = 24;

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const fetchPage = useCallback(
    async (reset: boolean) => {
      if (loadingRef.current) return;
      loadingRef.current = true;
      const nextOffset = reset ? 0 : offset;
      if (reset) {
        setLoading(true);
        setError(null);
      } else {
        setLoadingMore(true);
      }
      try {
        const res = await searchModrinth({
          query: debouncedQuery,
          loader,
          gameVersion: mcVersion,
          offset: nextOffset,
          limit,
          index:
            sort === 'newest'
              ? 'newest'
              : sort === 'updated'
                ? 'updated'
                : sort === 'relevance'
                  ? 'relevance'
                  : 'downloads',
        });
        setTotal(res.total_hits);
        setHits((prev) => (reset ? res.hits : [...prev, ...res.hits]));
        setOffset(nextOffset + res.hits.length);
        setHasMore(nextOffset + res.hits.length < res.total_hits);
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Search failed';
        setError(msg);
        addToast(msg, 'error');
        if (reset) setHits([]);
      } finally {
        setLoading(false);
        setLoadingMore(false);
        loadingRef.current = false;
      }
    },
    [debouncedQuery, loader, mcVersion, sort, offset, addToast],
  );

  useEffect(() => {
    setHits([]);
    setOffset(0);
    setHasMore(true);
    void fetchPage(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedQuery, loader, mcVersion, sort]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && hasMore && !loading && !loadingMore) {
          void fetchPage(false);
        }
      },
      { rootMargin: '240px' },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [hasMore, loading, loadingMore, fetchPage]);

  const installedIds = new Set(installed.map((i) => i.project_id));

  async function doInstall(hit: ModrinthHit, version: ModrinthVersion) {
    setInstallTarget(null);
    setInstallingId(hit.project_id);
    setProgress(20);
    try {
      const file = primaryFile(version);
      if (!file) {
        addToast('No downloadable file on this version', 'error');
        return;
      }
      setProgress(50);
      addToast(`Downloading ${file.filename} → plugins/`, 'info');
      await pullFileToServer(server.uuid, file.url, file.filename);
      setProgress(100);
      const item: InstalledContent = {
        uuid: crypto.randomUUID(),
        server_uuid: server.uuid,
        source: 'modrinth',
        project_id: hit.project_id,
        project_slug: hit.slug,
        project_name: hit.title,
        kind: 'plugin',
        version_id: version.id,
        version_number: version.version_number,
        filename: file.filename,
        file_path: `plugins/${file.filename}`,
        size_bytes: file.size,
        installed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      setInstalled((prev) => [item, ...prev.filter((i) => i.project_id !== hit.project_id)]);
      addToast(
        `${hit.title} v${version.version_number} installed to /home/container/plugins. Restart to apply.`,
        'success',
      );
    } catch (err) {
      addToast(err instanceof Error ? err.message : 'Install failed', 'error');
    } finally {
      setInstallingId(null);
      setProgress(null);
    }
  }

  return (
    <ServerContentContainer
      title='Plugin Manager'
      subtitle='Discover and install Minecraft plugins from Modrinth.'
      contentRight={
        <Badge color='teal' variant='light' size='sm'>
          {total > 0 ? `${total.toLocaleString()} plugins` : 'Modrinth'}
        </Badge>
      }
    >
      <Stack gap='md'>
        <Card
          padding='sm'
          radius='md'
          withBorder
          style={{
            background: 'var(--mantine-color-dark-6)',
            borderColor: 'var(--mantine-color-dark-4)',
          }}
        >
          <Group gap='sm' align='flex-end' wrap='wrap'>
            <Select
              label='Minecraft'
              data={['1.21.8', '1.21.4', '1.21.1', '1.20.6', '1.20.4', '1.20.1', '1.19.4']}
              value={mcVersion}
              onChange={setMcVersion}
              w={120}
              size='sm'
              clearable
              placeholder='Any'
            />
            <Select
              label='Loader'
              data={[
                { value: 'paper', label: 'Paper' },
                { value: 'purpur', label: 'Purpur' },
                { value: 'spigot', label: 'Spigot' },
                { value: 'bukkit', label: 'Bukkit' },
                { value: 'folia', label: 'Folia' },
                { value: 'velocity', label: 'Velocity' },
                { value: 'waterfall', label: 'Waterfall' },
                { value: 'bungeecord', label: 'BungeeCord' },
              ]}
              value={loader}
              onChange={setLoader}
              w={130}
              size='sm'
              clearable
              placeholder='Any'
            />
            <Select
              label='Sort'
              data={[
                { value: 'downloads', label: 'Downloads' },
                { value: 'updated', label: 'Updated' },
                { value: 'newest', label: 'Newest' },
                { value: 'relevance', label: 'Relevance' },
              ]}
              value={sort}
              onChange={setSort}
              w={130}
              size='sm'
            />
            <TextInput
              label='Search'
              placeholder='Search plugins…'
              leftSection={<FontAwesomeIcon icon={faSearch} size='sm' />}
              value={query}
              onChange={(e) => setQuery(e.currentTarget.value)}
              style={{ flex: 1, minWidth: 180 }}
              size='sm'
            />
          </Group>
        </Card>

        {loading && hits.length === 0 ? (
          <Group justify='center' py='xl'>
            <Loader />
            <Text size='sm' c='dimmed'>
              Loading plugins from Modrinth…
            </Text>
          </Group>
        ) : error && hits.length === 0 ? (
          <Stack gap='sm' align='center' py='xl'>
            <Text c='red' ta='center'>
              {error}
            </Text>
            <Button size='sm' onClick={() => void fetchPage(true)}>
              Retry
            </Button>
          </Stack>
        ) : hits.length === 0 ? (
          <Text c='dimmed' ta='center' py='xl'>
            No plugins found. Clear filters or try another search.
          </Text>
        ) : (
          <SimpleGrid cols={{ base: 1, sm: 2, lg: 3 }} spacing='md'>
            {hits.map((hit) => (
              <ProjectCard
                key={hit.project_id}
                hit={hit}
                installed={installedIds.has(hit.project_id)}
                installing={installingId === hit.project_id}
                progress={installingId === hit.project_id ? progress : null}
                onInstall={() => setInstallTarget(hit)}
                onRemove={() => {
                  const item = installed.find((i) => i.project_id === hit.project_id);
                  if (item) setRemoveTarget(item);
                }}
              />
            ))}
          </SimpleGrid>
        )}

        <div ref={sentinelRef} style={{ height: 1 }} />
        {loadingMore && (
          <Group justify='center' py='md'>
            <Loader size='sm' />
            <Text size='sm' c='dimmed'>
              Loading more plugins…
            </Text>
          </Group>
        )}
        {!hasMore && hits.length > 0 && (
          <Text size='sm' c='dimmed' ta='center' py='sm'>
            End of results · {total.toLocaleString()} plugins
          </Text>
        )}
      </Stack>

      <ContentInstallModal
        opened={installTarget !== null}
        onClose={() => setInstallTarget(null)}
        project={installTarget}
        loader={loader}
        gameVersion={mcVersion}
        onConfirm={(version) => {
          if (installTarget) void doInstall(installTarget, version);
        }}
      />

      <ContentRemoveModal
        opened={removeTarget !== null}
        onClose={() => setRemoveTarget(null)}
        content={removeTarget}
        onRemoved={(uuid) => {
          setInstalled((prev) => prev.filter((i) => i.uuid !== uuid));
          setRemoveTarget(null);
        }}
      />
    </ServerContentContainer>
  );
}
