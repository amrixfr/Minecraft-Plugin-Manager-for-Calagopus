import { useState } from 'react';
import Button from '@/elements/buttons/Button.tsx';
import Switch from '@/elements/input/Switch.tsx';
import NumberInput from '@/elements/input/NumberInput.tsx';
import TextInput from '@/elements/input/TextInput.tsx';
import Stack from '@/elements/layout/Stack.tsx';
import Text from '@/elements/typography/Text.tsx';
import Title from '@/elements/typography/Title.tsx';

export default function AdminContentPage() {
  const [modrinth, setModrinth] = useState(true);
  const [curseforge, setCurseforge] = useState(false);
  const [hangar, setHangar] = useState(true);
  const [spigotmc, setSpigotmc] = useState(true);
  const [maxMb, setMaxMb] = useState<number | string>(250);
  const [apiKey, setApiKey] = useState('');

  return (
    <Stack gap='lg' maw={560}>
      <div>
        <Title order={3}>Minecraft Content Manager</Title>
        <Text size='sm' c='dimmed'>
          Configure providers and limits · by nino
        </Text>
      </div>

      <Stack gap='sm'>
        <Text fw={500}>Providers</Text>
        <Switch
          label='Modrinth'
          checked={modrinth}
          onChange={(e) => setModrinth(e.currentTarget.checked)}
        />
        <Switch
          label='CurseForge'
          checked={curseforge}
          onChange={(e) => setCurseforge(e.currentTarget.checked)}
        />
        <Switch label='Hangar' checked={hangar} onChange={(e) => setHangar(e.currentTarget.checked)} />
        <Switch
          label='SpigotMC'
          checked={spigotmc}
          onChange={(e) => setSpigotmc(e.currentTarget.checked)}
        />
      </Stack>

      <TextInput
        label='CurseForge API Key'
        description='Required when CurseForge is enabled'
        type='password'
        value={apiKey}
        onChange={(e) => setApiKey(e.currentTarget.value)}
      />

      <NumberInput
        label='Max download size (MiB)'
        value={maxMb}
        onChange={setMaxMb}
        min={1}
        max={1024}
      />

      <Button color='blue'>Save settings</Button>
    </Stack>
  );
}
