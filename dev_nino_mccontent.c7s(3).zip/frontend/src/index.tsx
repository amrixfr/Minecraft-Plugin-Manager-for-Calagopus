import { faPuzzlePiece } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Extension, ExtensionContext } from 'shared';
import AdminContentPage from './pages/admin/AdminContentPage';
import ServerContentPage from './pages/server/ServerContentPage';

class NinoMccontentExtension extends Extension {
  public cardConfigurationPage: React.FC | null = AdminContentPage;
  public cardIcon: React.ReactNode = <FontAwesomeIcon icon={faPuzzlePiece} />;

  public initialize(ctx: ExtensionContext): void {
    ctx.extensionRegistry.enterRoutes((routes) =>
      routes.addServerRoute({
        name: () => 'Plugins',
        icon: faPuzzlePiece,
        path: '/content',
        element: ServerContentPage,
        permission: 'content.read',
      }),
    );

    ctx.extensionRegistry.enterPermissionIcons((icons) =>
      icons
        .addServerPermissionIcon('content', <FontAwesomeIcon icon={faPuzzlePiece} />)
        .addAdminPermissionIcon('content', <FontAwesomeIcon icon={faPuzzlePiece} />),
    );
  }
}

export default new NinoMccontentExtension();
