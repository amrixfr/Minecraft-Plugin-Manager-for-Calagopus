import { axiosInstance } from '@/api/axios';

/**
 * Pull a remote URL into the server filesystem via the panel API:
 * POST /api/client/servers/{uuid}/files/pull
 *
 * Body (from panel OpenAPI):
 *   { url, root?, name?, use_header?, foreground? }
 *
 * root defaults to "/". Use root "/plugins" so the file lands in
 * /home/container/plugins on the server.
 */
export default async function pullFileToServer(
  serverUuid: string,
  url: string,
  filename: string,
): Promise<void> {
  const { data, status } = await axiosInstance.post(
    `/api/client/servers/${serverUuid}/files/pull`,
    {
      url,
      root: '/plugins',
      name: filename,
      foreground: true,
    },
  );

  // 202 = background operation started
  if (status === 202 && data?.identifier) {
    // Optionally poll pull/query — for now treat as accepted
    return;
  }
}
