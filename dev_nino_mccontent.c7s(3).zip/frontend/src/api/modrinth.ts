/** Direct Modrinth API helpers (public, no auth required). */

export interface ModrinthHit {
  project_id: string;
  project_type: string;
  slug: string;
  author: string;
  title: string;
  description: string;
  categories: string[];
  versions: string[];
  downloads: number;
  icon_url: string | null;
  date_modified: string;
}

export interface ModrinthSearchResponse {
  hits: ModrinthHit[];
  offset: number;
  limit: number;
  total_hits: number;
}

export interface ModrinthVersionFile {
  url: string;
  filename: string;
  size: number;
  primary: boolean;
}

export interface ModrinthVersion {
  id: string;
  project_id: string;
  name: string;
  version_number: string;
  version_type: string;
  loaders: string[];
  game_versions: string[];
  files: ModrinthVersionFile[];
}

const UA = 'dev.nino.mccontent/0.1.0 (nino)';

export async function searchModrinth(opts: {
  query?: string;
  offset?: number;
  limit?: number;
  index?: string;
  loader?: string | null;
  gameVersion?: string | null;
}): Promise<ModrinthSearchResponse> {
  const limit = opts.limit ?? 24;
  const offset = opts.offset ?? 0;
  const index = opts.index ?? 'downloads';

  // facets: only project_type=plugin; optional loader/version as extra AND groups
  const facetGroups: string[][] = [['project_type:plugin']];
  if (opts.loader) {
    facetGroups.push([`categories:${opts.loader.toLowerCase()}`]);
  }
  if (opts.gameVersion) {
    facetGroups.push([`versions:${opts.gameVersion}`]);
  }

  const params = new URLSearchParams();
  if (opts.query && opts.query.trim()) {
    params.set('query', opts.query.trim());
  }
  params.set('limit', String(limit));
  params.set('offset', String(offset));
  params.set('index', index);
  params.set('facets', JSON.stringify(facetGroups));

  const res = await fetch(`https://api.modrinth.com/v2/search?${params.toString()}`, {
    headers: { 'User-Agent': UA },
  });
  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Modrinth search failed (${res.status}): ${body.slice(0, 120)}`);
  }
  return res.json();
}

export async function getProjectVersions(
  projectId: string,
  loader?: string | null,
  gameVersion?: string | null,
): Promise<ModrinthVersion[]> {
  const params = new URLSearchParams();
  if (loader) params.set('loaders', JSON.stringify([loader.toLowerCase()]));
  if (gameVersion) params.set('game_versions', JSON.stringify([gameVersion]));

  const qs = params.toString();
  const url = `https://api.modrinth.com/v2/project/${encodeURIComponent(projectId)}/version${qs ? `?${qs}` : ''}`;
  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error(`Modrinth versions failed: ${res.status}`);
  return res.json();
}

export function primaryFile(version: ModrinthVersion): ModrinthVersionFile | null {
  return version.files.find((f) => f.primary) ?? version.files[0] ?? null;
}
