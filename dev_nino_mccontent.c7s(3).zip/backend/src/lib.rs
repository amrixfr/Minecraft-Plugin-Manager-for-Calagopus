use indexmap::IndexMap;
use shared::{
    Extendible, State,
    extensions::{
        Extension, ExtensionPermissionsBuilder, ExtensionRouteBuilder,
        settings::ExtensionSettingsDeserializer,
    },
    models::{
        BaseModel, CreatableModel, DeletableModel, ListenerPriority, UpdatableModel,
        server::{ApiServerFeatureLimits, Server},
    },
    permissions::PermissionGroup,
};
use std::sync::Arc;

mod db;
mod model;
mod providers;
mod records;
mod routes;
mod service;
mod settings;

#[derive(Default)]
pub struct ExtensionStruct;

#[async_trait::async_trait]
impl Extension for ExtensionStruct {
    async fn initialize(&mut self, _state: State) {
        Server::register_model_extension(model::ServerExtension);

        Server::register_create_handler(
            ListenerPriority::Normal,
            |options, query_builder, _state, _transaction| {
                Box::pin(async move {
                    let limit = options
                        .feature_limits
                        .parse_extended::<model::ExtendedApiServerFeatureLimits>()
                        .ok()
                        .and_then(|extended| extended.content_installs)
                        .unwrap_or(0);

                    query_builder.set("content_install_limit", limit.max(0));
                    Ok(())
                })
            },
        );

        Server::register_update_handler(
            ListenerPriority::Normal,
            |_server, options, query_builder, _state, _transaction| {
                Box::pin(async move {
                    if let Some(feature_limits) = &options.feature_limits
                        && let Ok(extended) =
                            feature_limits.parse_extended::<model::ExtendedApiServerFeatureLimits>()
                        && let Some(value) = extended.content_installs
                    {
                        query_builder.set("content_install_limit", Some(value.max(0)));
                    }
                    Ok(())
                })
            },
        );

        Server::register_delete_handler(
            ListenerPriority::Normal,
            |server, _options, state, _transaction| {
                Box::pin(async move {
                    match db::InstalledContent::list_for_server(&state.database, server.uuid).await
                    {
                        Ok(items) => {
                            for item in items {
                                let _ = service::remove(&state, &item).await;
                            }
                        }
                        Err(err) => tracing::warn!(
                            server = %server.uuid,
                            "failed to load content for cleanup: {err:?}"
                        ),
                    }
                    Ok(())
                })
            },
        );

        ApiServerFeatureLimits::extend_validated(
            |server, _state| {
                Box::pin(async move {
                    Ok(server.parse_model_extension::<model::ServerExtension>()?)
                })
            },
            |_limits, extension, _state| model::ExtendedApiServerFeatureLimits {
                content_installs: Some(extension.content_install_limit),
            },
        );
    }

    async fn initialize_router(
        &mut self,
        state: State,
        builder: ExtensionRouteBuilder,
    ) -> ExtensionRouteBuilder {
        builder
            .add_admin_api_router(|router| {
                router.nest(
                    "/extensions/dev.nino.mccontent",
                    routes::admin::router(&state),
                )
            })
            .add_client_server_api_router(|router| {
                router.nest("/content", routes::server::router(&state))
            })
    }

    async fn initialize_permissions(
        &mut self,
        _state: State,
        mut builder: ExtensionPermissionsBuilder,
    ) -> ExtensionPermissionsBuilder {
        builder.server_permissions.insert(
            "content",
            PermissionGroup {
                description: "Permissions that control the ability to manage plugins, mods and modpacks for this server.",
                permissions: IndexMap::from([
                    (
                        "read",
                        "Allows viewing the server's installed plugins, mods and modpacks.",
                    ),
                    (
                        "install",
                        "Allows searching and installing plugins, mods and modpacks.",
                    ),
                    (
                        "remove",
                        "Allows removing installed content from the server.",
                    ),
                ]),
            },
        );

        builder.admin_permissions.insert(
            "content",
            PermissionGroup {
                description: "Permissions that control the ability to manage the Minecraft Content Manager extension.",
                permissions: IndexMap::from([
                    (
                        "read",
                        "Allows viewing the extension's settings and all installed content across the panel.",
                    ),
                    (
                        "manage",
                        "Allows changing settings and managing installed content.",
                    ),
                ]),
            },
        );

        builder
    }

    async fn settings_deserializer(&self, _state: State) -> ExtensionSettingsDeserializer {
        Arc::new(settings::ExtensionSettingsDataDeserializer)
    }
}
