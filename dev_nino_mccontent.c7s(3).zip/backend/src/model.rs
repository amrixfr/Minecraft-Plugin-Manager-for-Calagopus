use garde::Validate;
use serde::{Deserialize, Serialize};
use shared::{
    database::DatabaseError,
    models::{
        BaseModel, ModelExtension, ModelExtensionMapType, SafeModelExtension, server::Server,
    },
};
use sqlx::{Row, postgres::PgRow};
use std::collections::BTreeMap;
use utoipa::ToSchema;

/// The extension's columns on `servers` – a per-server install cap.
#[derive(Serialize, Deserialize)]
pub struct ServerExtensionData {
    pub content_install_limit: i32,
}

pub struct ServerExtension;

impl SafeModelExtension for ServerExtension {
    type Value = ServerExtensionData;

    fn name() -> &'static str {
        ServerExtension.extension_name()
    }
}

impl ModelExtension for ServerExtension {
    fn extension_name(&self) -> &'static str {
        "dev.nino.mccontent"
    }

    fn extended_columns(&self, prefix: &str) -> BTreeMap<&'static str, compact_str::CompactString> {
        BTreeMap::from([(
            "servers.content_install_limit",
            compact_str::format_compact!("{prefix}content_install_limit"),
        )])
    }

    fn map_extended(
        &self,
        prefix: &str,
        row: &PgRow,
    ) -> Result<ModelExtensionMapType, DatabaseError> {
        Ok(Box::new(ServerExtensionData {
            content_install_limit: row.try_get(
                compact_str::format_compact!("{prefix}content_install_limit").as_str(),
            )?,
        }))
    }
}

/// Extension fields on `ApiServerFeatureLimits`.
#[derive(ToSchema, Validate, Serialize, Deserialize)]
pub struct ExtendedApiServerFeatureLimits {
    #[garde(range(min = 0))]
    #[schema(minimum = 0)]
    pub content_installs: Option<i32>,
}

/// Reads a server's configured content install limit from its extension data.
pub fn content_install_limit(server: &Server) -> Result<i32, DatabaseError> {
    Ok(server
        .parse_model_extension::<ServerExtension>()?
        .content_install_limit)
}
