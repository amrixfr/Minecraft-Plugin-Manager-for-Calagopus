use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};
use shared::database::Database;
use utoipa::ToSchema;
use uuid::Uuid;

#[derive(Debug, Clone, sqlx::FromRow, Serialize, Deserialize, ToSchema)]
pub struct InstalledContent {
    pub uuid: Uuid,
    pub server_uuid: Uuid,
    pub source: String,
    pub project_id: String,
    pub project_slug: String,
    pub project_name: String,
    pub kind: String,
    pub version_id: String,
    pub version_number: String,
    pub filename: String,
    pub file_path: String,
    pub size_bytes: i64,
    pub installed_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}

impl InstalledContent {
    pub async fn list_for_server(
        database: &Database,
        server_uuid: Uuid,
    ) -> Result<Vec<Self>, sqlx::Error> {
        sqlx::query_as::<_, Self>(
            r#"
            SELECT * FROM dev_nino_mccontent_installed
            WHERE server_uuid = $1
            ORDER BY installed_at DESC
            "#,
        )
        .bind(server_uuid)
        .fetch_all(database.read())
        .await
    }

    pub async fn count_for_server(database: &Database, server_uuid: Uuid) -> Result<i64, sqlx::Error> {
        let (count,): (i64,) = sqlx::query_as(
            r#"
            SELECT COUNT(*) FROM dev_nino_mccontent_installed
            WHERE server_uuid = $1
            "#,
        )
        .bind(server_uuid)
        .fetch_one(database.read())
        .await?;
        Ok(count)
    }

    pub async fn by_uuid(database: &Database, uuid: Uuid) -> Result<Option<Self>, sqlx::Error> {
        sqlx::query_as::<_, Self>(
            r#"
            SELECT * FROM dev_nino_mccontent_installed
            WHERE uuid = $1
            "#,
        )
        .bind(uuid)
        .fetch_optional(database.read())
        .await
    }

    pub async fn insert(
        database: &Database,
        server_uuid: Uuid,
        source: &str,
        project_id: &str,
        project_slug: &str,
        project_name: &str,
        kind: &str,
        version_id: &str,
        version_number: &str,
        filename: &str,
        file_path: &str,
        size_bytes: i64,
    ) -> Result<Self, sqlx::Error> {
        sqlx::query_as::<_, Self>(
            r#"
            INSERT INTO dev_nino_mccontent_installed
                (server_uuid, source, project_id, project_slug, project_name, kind,
                 version_id, version_number, filename, file_path, size_bytes)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
            RETURNING *
            "#,
        )
        .bind(server_uuid)
        .bind(source)
        .bind(project_id)
        .bind(project_slug)
        .bind(project_name)
        .bind(kind)
        .bind(version_id)
        .bind(version_number)
        .bind(filename)
        .bind(file_path)
        .bind(size_bytes)
        .fetch_one(database.write())
        .await
    }

    pub async fn delete(database: &Database, uuid: Uuid) -> Result<(), sqlx::Error> {
        sqlx::query(
            r#"
            DELETE FROM dev_nino_mccontent_installed
            WHERE uuid = $1
            "#,
        )
        .bind(uuid)
        .execute(database.write())
        .await?;
        Ok(())
    }

    pub async fn list_all(
        database: &Database,
        search: Option<&str>,
        limit: i64,
        offset: i64,
    ) -> Result<Vec<Self>, sqlx::Error> {
        if let Some(q) = search {
            let pattern = format!("%{q}%");
            sqlx::query_as::<_, Self>(
                r#"
                SELECT * FROM dev_nino_mccontent_installed
                WHERE project_name ILIKE $1 OR project_slug ILIKE $1 OR filename ILIKE $1
                ORDER BY installed_at DESC
                LIMIT $2 OFFSET $3
                "#,
            )
            .bind(pattern)
            .bind(limit)
            .bind(offset)
            .fetch_all(database.read())
            .await
        } else {
            sqlx::query_as::<_, Self>(
                r#"
                SELECT * FROM dev_nino_mccontent_installed
                ORDER BY installed_at DESC
                LIMIT $1 OFFSET $2
                "#,
            )
            .bind(limit)
            .bind(offset)
            .fetch_all(database.read())
            .await
        }
    }
}
