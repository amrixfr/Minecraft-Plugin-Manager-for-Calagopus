use super::{ContentKind, ContentProvider, ProjectSummary, VersionInfo};
use reqwest::Client;

pub struct CurseForgeProvider {
    client: Client,
    api_key: String,
}

impl CurseForgeProvider {
    pub fn new(api_key: String) -> Self {
        Self {
            client: Client::builder()
                .user_agent("dev.nino.mccontent/0.1.0 (nino)")
                .build()
                .expect("failed to build reqwest client"),
            api_key,
        }
    }
}

#[async_trait::async_trait]
impl ContentProvider for CurseForgeProvider {
    fn name(&self) -> &'static str {
        "curseforge"
    }

    async fn search(
        &self,
        query: &str,
        kind: ContentKind,
        _game_version: Option<&str>,
        _loader: Option<&str>,
        limit: u32,
    ) -> anyhow::Result<Vec<ProjectSummary>> {
        // Class IDs: 6 = Mods, 4471 = Modpacks, 5 = Bukkit Plugins (approx)
        let class_id = match kind {
            ContentKind::Mod => 6,
            ContentKind::Modpack => 4471,
            ContentKind::Plugin => 5,
        };

        let url = format!(
            "https://api.curseforge.com/v1/mods/search?gameId=432&classId={class_id}&searchFilter={}&pageSize={}",
            query.replace(' ', "%20").replace('&', "%26").replace('=', "%3D").replace('?', "%3F").replace('#', "%23"),
            limit
        );

        let resp = self
            .client
            .get(&url)
            .header("x-api-key", &self.api_key)
            .send()
            .await?
            .error_for_status()?;

        let body: serde_json::Value = resp.json().await?;
        let data = body["data"].as_array().cloned().unwrap_or_default();

        let mut results = Vec::new();
        for item in data {
            results.push(ProjectSummary {
                id: item["id"].as_u64().unwrap_or(0).to_string(),
                slug: item["slug"].as_str().unwrap_or_default().into(),
                name: item["name"].as_str().unwrap_or_default().into(),
                description: item["summary"].as_str().unwrap_or_default().into(),
                author: item["authors"]
                    .as_array()
                    .and_then(|a| a.first())
                    .and_then(|a| a["name"].as_str())
                    .unwrap_or_default()
                    .into(),
                icon_url: item["logo"]["url"].as_str().map(String::from),
                downloads: item["downloadCount"].as_u64().unwrap_or(0),
                kind,
                source: "curseforge".into(),
                loaders: Vec::new(),
                game_versions: Vec::new(),
            });
        }

        Ok(results)
    }

    async fn get_versions(
        &self,
        project_id: &str,
        _game_version: Option<&str>,
        _loader: Option<&str>,
    ) -> anyhow::Result<Vec<VersionInfo>> {
        let url = format!("https://api.curseforge.com/v1/mods/{project_id}/files");
        let resp = self
            .client
            .get(&url)
            .header("x-api-key", &self.api_key)
            .send()
            .await?
            .error_for_status()?;

        let body: serde_json::Value = resp.json().await?;
        let data = body["data"].as_array().cloned().unwrap_or_default();

        let mut results = Vec::new();
        for f in data {
            results.push(VersionInfo {
                id: f["id"].as_u64().unwrap_or(0).to_string(),
                name: f["displayName"].as_str().unwrap_or_default().into(),
                version_number: f["fileName"].as_str().unwrap_or_default().into(),
                game_versions: f["gameVersions"]
                    .as_array()
                    .map(|a| {
                        a.iter()
                            .filter_map(|v| v.as_str().map(String::from))
                            .collect()
                    })
                    .unwrap_or_default(),
                loaders: Vec::new(),
                download_url: f["downloadUrl"].as_str().unwrap_or_default().into(),
                filename: f["fileName"].as_str().unwrap_or_default().into(),
                size_bytes: f["fileLength"].as_u64().unwrap_or(0),
                hashes: std::collections::HashMap::new(),
                release_type: "release".into(),
                dependencies: Vec::new(),
            });
        }

        Ok(results)
    }

    async fn get_project(&self, project_id: &str) -> anyhow::Result<ProjectSummary> {
        let url = format!("https://api.curseforge.com/v1/mods/{project_id}");
        let resp = self
            .client
            .get(&url)
            .header("x-api-key", &self.api_key)
            .send()
            .await?
            .error_for_status()?;

        let body: serde_json::Value = resp.json().await?;
        let p = &body["data"];

        Ok(ProjectSummary {
            id: p["id"].as_u64().unwrap_or(0).to_string(),
            slug: p["slug"].as_str().unwrap_or_default().into(),
            name: p["name"].as_str().unwrap_or_default().into(),
            description: p["summary"].as_str().unwrap_or_default().into(),
            author: String::new(),
            icon_url: p["logo"]["url"].as_str().map(String::from),
            downloads: p["downloadCount"].as_u64().unwrap_or(0),
            kind: ContentKind::Mod,
            source: "curseforge".into(),
            loaders: Vec::new(),
            game_versions: Vec::new(),
        })
    }
}
