mod curseforge;
mod hangar;
mod modrinth;
mod spigotmc;

use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

/// Content categories the extension understands.
#[derive(ToSchema, Serialize, Deserialize, Clone, Copy, PartialEq, Eq, Debug)]
#[serde(rename_all = "snake_case")]
pub enum ContentKind {
    Plugin,
    Mod,
    Modpack,
}

/// A project returned by a provider search.
#[derive(ToSchema, Serialize, Deserialize, Clone, Debug)]
pub struct ProjectSummary {
    pub id: String,
    pub slug: String,
    pub name: String,
    pub description: String,
    pub author: String,
    pub icon_url: Option<String>,
    pub downloads: u64,
    pub kind: ContentKind,
    pub source: String,
    pub loaders: Vec<String>,
    pub game_versions: Vec<String>,
}

/// A concrete downloadable version of a project.
#[derive(ToSchema, Serialize, Deserialize, Clone, Debug)]
pub struct VersionInfo {
    pub id: String,
    pub name: String,
    pub version_number: String,
    pub game_versions: Vec<String>,
    pub loaders: Vec<String>,
    pub download_url: String,
    pub filename: String,
    pub size_bytes: u64,
    pub hashes: std::collections::HashMap<String, String>,
    pub release_type: String,
    pub dependencies: Vec<Dependency>,
}

#[derive(ToSchema, Serialize, Deserialize, Clone, Debug)]
pub struct Dependency {
    pub project_id: String,
    pub version_id: Option<String>,
    pub dependency_type: String, // required | optional | embedded
}

#[async_trait::async_trait]
pub trait ContentProvider: Send + Sync {
    fn name(&self) -> &'static str;

    async fn search(
        &self,
        query: &str,
        kind: ContentKind,
        game_version: Option<&str>,
        loader: Option<&str>,
        limit: u32,
    ) -> anyhow::Result<Vec<ProjectSummary>>;

    async fn get_versions(
        &self,
        project_id: &str,
        game_version: Option<&str>,
        loader: Option<&str>,
    ) -> anyhow::Result<Vec<VersionInfo>>;

    async fn get_project(&self, project_id: &str) -> anyhow::Result<ProjectSummary>;
}

pub fn build_enabled(
    settings: &crate::settings::ProviderSettings,
) -> Vec<Box<dyn ContentProvider>> {
    let mut providers: Vec<Box<dyn ContentProvider>> = Vec::new();

    if settings.modrinth {
        providers.push(Box::new(modrinth::ModrinthProvider::new()));
    }
    if settings.curseforge {
        if let Some(key) = &settings.curseforge_api_key {
            if !key.is_empty() {
                providers.push(Box::new(curseforge::CurseForgeProvider::new(key.clone())));
            }
        }
    }
    if settings.hangar {
        providers.push(Box::new(hangar::HangarProvider::new()));
    }
    if settings.spigotmc {
        providers.push(Box::new(spigotmc::SpigotMcProvider::new()));
    }

    providers
}
