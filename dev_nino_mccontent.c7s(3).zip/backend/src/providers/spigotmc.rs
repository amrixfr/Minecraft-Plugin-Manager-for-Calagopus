use super::{ContentKind, ContentProvider, ProjectSummary, VersionInfo};
use reqwest::Client;

/// SpigotMC resources API (limited public endpoints).
pub struct SpigotMcProvider {
    client: Client,
}

impl SpigotMcProvider {
    pub fn new() -> Self {
        Self {
            client: Client::builder()
                .user_agent("dev.nino.mccontent/0.1.0 (nino)")
                .build()
                .expect("failed to build reqwest client"),
        }
    }
}

#[async_trait::async_trait]
impl ContentProvider for SpigotMcProvider {
    fn name(&self) -> &'static str {
        "spigotmc"
    }

    async fn search(
        &self,
        query: &str,
        kind: ContentKind,
        _game_version: Option<&str>,
        _loader: Option<&str>,
        limit: u32,
    ) -> anyhow::Result<Vec<ProjectSummary>> {
        if kind != ContentKind::Plugin {
            return Ok(Vec::new());
        }

        // Spigot does not offer a rich public search API; this is a simplified stub
        // that can be expanded with scraping or a local index later.
        let _ = (query, limit);
        Ok(Vec::new())
    }

    async fn get_versions(
        &self,
        _project_id: &str,
        _game_version: Option<&str>,
        _loader: Option<&str>,
    ) -> anyhow::Result<Vec<VersionInfo>> {
        Ok(Vec::new())
    }

    async fn get_project(&self, project_id: &str) -> anyhow::Result<ProjectSummary> {
        Ok(ProjectSummary {
            id: project_id.to_string(),
            slug: project_id.to_string(),
            name: format!("Spigot resource {project_id}"),
            description: String::new(),
            author: String::new(),
            icon_url: None,
            downloads: 0,
            kind: ContentKind::Plugin,
            source: "spigotmc".into(),
            loaders: vec!["spigot".into(), "paper".into()],
            game_versions: Vec::new(),
        })
    }
}
