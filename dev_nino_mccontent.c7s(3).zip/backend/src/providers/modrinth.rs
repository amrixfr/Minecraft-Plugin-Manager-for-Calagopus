use super::{ContentKind, ContentProvider, ProjectSummary, VersionInfo};
use reqwest::Client;

pub struct ModrinthProvider {
    client: Client,
}

impl ModrinthProvider {
    pub fn new() -> Self {
        Self {
            client: Client::builder()
                .user_agent("dev.nino.mccontent/0.1.0 (nino)")
                .build()
                .expect("failed to build reqwest client"),
        }
    }
}

#[async_trait::async_trait]
impl ContentProvider for ModrinthProvider {
    fn name(&self) -> &'static str {
        "modrinth"
    }

    async fn search(
        &self,
        query: &str,
        kind: ContentKind,
        game_version: Option<&str>,
        loader: Option<&str>,
        limit: u32,
    ) -> anyhow::Result<Vec<ProjectSummary>> {
        let project_type = match kind {
            ContentKind::Plugin => "plugin",
            ContentKind::Mod => "mod",
            ContentKind::Modpack => "modpack",
        };

        let mut facets = vec![format!(r#"["project_type:{project_type}"]"#)];
        if let Some(v) = game_version {
            facets.push(format!(r#"["versions:{v}"]"#));
        }
        if let Some(l) = loader {
            facets.push(format!(r#"["categories:{l}"]"#));
        }

        let url = format!(
            "https://api.modrinth.com/v2/search?query={}&limit={}&facets=[{}]",
            query.replace(' ', "%20").replace('&', "%26").replace('=', "%3D").replace('?', "%3F").replace('#', "%23"),
            limit,
            facets.join(",")
        );

        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let body: serde_json::Value = resp.json().await?;

        let hits = body["hits"].as_array().cloned().unwrap_or_default();
        let mut results = Vec::with_capacity(hits.len());

        for hit in hits {
            results.push(ProjectSummary {
                id: hit["project_id"].as_str().unwrap_or_default().into(),
                slug: hit["slug"].as_str().unwrap_or_default().into(),
                name: hit["title"].as_str().unwrap_or_default().into(),
                description: hit["description"].as_str().unwrap_or_default().into(),
                author: hit["author"].as_str().unwrap_or_default().into(),
                icon_url: hit["icon_url"].as_str().map(String::from),
                downloads: hit["downloads"].as_u64().unwrap_or(0),
                kind,
                source: "modrinth".into(),
                loaders: hit["categories"]
                    .as_array()
                    .map(|a| {
                        a.iter()
                            .filter_map(|v| v.as_str().map(String::from))
                            .collect()
                    })
                    .unwrap_or_default(),
                game_versions: hit["versions"]
                    .as_array()
                    .map(|a| {
                        a.iter()
                            .filter_map(|v| v.as_str().map(String::from))
                            .collect()
                    })
                    .unwrap_or_default(),
            });
        }

        Ok(results)
    }

    async fn get_versions(
        &self,
        project_id: &str,
        game_version: Option<&str>,
        loader: Option<&str>,
    ) -> anyhow::Result<Vec<VersionInfo>> {
        let url = format!("https://api.modrinth.com/v2/project/{project_id}/version");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let versions: Vec<serde_json::Value> = resp.json().await?;

        let mut results = Vec::new();
        for v in versions {
            let loaders: Vec<String> = v["loaders"]
                .as_array()
                .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
                .unwrap_or_default();
            let game_versions: Vec<String> = v["game_versions"]
                .as_array()
                .map(|a| a.iter().filter_map(|x| x.as_str().map(String::from)).collect())
                .unwrap_or_default();

            if let Some(gv) = game_version {
                if !game_versions.iter().any(|g| g == gv) {
                    continue;
                }
            }
            if let Some(l) = loader {
                if !loaders.iter().any(|x| x.eq_ignore_ascii_case(l)) {
                    continue;
                }
            }

            let file = v["files"]
                .as_array()
                .and_then(|a| a.iter().find(|f| f["primary"].as_bool().unwrap_or(false)))
                .or_else(|| v["files"].as_array().and_then(|a| a.first()));

            let Some(file) = file else { continue };

            let mut hashes = std::collections::HashMap::new();
            if let Some(h) = file["hashes"].as_object() {
                for (k, val) in h {
                    if let Some(s) = val.as_str() {
                        hashes.insert(k.clone(), s.to_string());
                    }
                }
            }

            results.push(VersionInfo {
                id: v["id"].as_str().unwrap_or_default().into(),
                name: v["name"].as_str().unwrap_or_default().into(),
                version_number: v["version_number"].as_str().unwrap_or_default().into(),
                game_versions,
                loaders,
                download_url: file["url"].as_str().unwrap_or_default().into(),
                filename: file["filename"].as_str().unwrap_or_default().into(),
                size_bytes: file["size"].as_u64().unwrap_or(0),
                hashes,
                release_type: v["version_type"].as_str().unwrap_or("release").into(),
                dependencies: Vec::new(), // simplified
            });
        }

        Ok(results)
    }

    async fn get_project(&self, project_id: &str) -> anyhow::Result<ProjectSummary> {
        let url = format!("https://api.modrinth.com/v2/project/{project_id}");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let p: serde_json::Value = resp.json().await?;

        let kind = match p["project_type"].as_str().unwrap_or("") {
            "plugin" => ContentKind::Plugin,
            "modpack" => ContentKind::Modpack,
            _ => ContentKind::Mod,
        };

        Ok(ProjectSummary {
            id: p["id"].as_str().unwrap_or_default().into(),
            slug: p["slug"].as_str().unwrap_or_default().into(),
            name: p["title"].as_str().unwrap_or_default().into(),
            description: p["description"].as_str().unwrap_or_default().into(),
            author: String::new(),
            icon_url: p["icon_url"].as_str().map(String::from),
            downloads: p["downloads"].as_u64().unwrap_or(0),
            kind,
            source: "modrinth".into(),
            loaders: p["loaders"]
                .as_array()
                .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default(),
            game_versions: p["game_versions"]
                .as_array()
                .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                .unwrap_or_default(),
        })
    }
}
