use super::{ContentKind, ContentProvider, ProjectSummary, VersionInfo};
use reqwest::Client;

/// Hangar (PaperMC) provider – plugins only.
pub struct HangarProvider {
    client: Client,
}

impl HangarProvider {
    pub fn new() -> Self {
        Self {
            client: Client::builder()
                .user_agent("dev.nino.mccontent/0.1.0 (nino)")
                .build()
                .expect("failed to build reqwest client"),
        }
    }
}

#[async_trait::async_trait]
impl ContentProvider for HangarProvider {
    fn name(&self) -> &'static str {
        "hangar"
    }

    async fn search(
        &self,
        query: &str,
        kind: ContentKind,
        _game_version: Option<&str>,
        _loader: Option<&str>,
        limit: u32,
    ) -> anyhow::Result<Vec<ProjectSummary>> {
        if kind != ContentKind::Plugin {
            return Ok(Vec::new());
        }

        let url = format!(
            "https://hangar.papermc.io/api/v1/projects?q={}&limit={}&sort=-downloads",
            query.replace(' ', "%20").replace('&', "%26").replace('=', "%3D").replace('?', "%3F").replace('#', "%23"),
            limit
        );

        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let body: serde_json::Value = resp.json().await?;
        let result = body["result"].as_array().cloned().unwrap_or_default();

        let mut results = Vec::new();
        for item in result {
            results.push(ProjectSummary {
                id: item["namespace"]["owner"].as_str().unwrap_or_default().to_string()
                    + "/"
                    + item["namespace"]["slug"].as_str().unwrap_or_default(),
                slug: item["namespace"]["slug"].as_str().unwrap_or_default().into(),
                name: item["name"].as_str().unwrap_or_default().into(),
                description: item["description"].as_str().unwrap_or_default().into(),
                author: item["namespace"]["owner"].as_str().unwrap_or_default().into(),
                icon_url: item["avatarUrl"].as_str().map(String::from),
                downloads: item["stats"]["downloads"].as_u64().unwrap_or(0),
                kind: ContentKind::Plugin,
                source: "hangar".into(),
                loaders: vec!["paper".into(), "purpur".into()],
                game_versions: Vec::new(),
            });
        }

        Ok(results)
    }

    async fn get_versions(
        &self,
        project_id: &str,
        _game_version: Option<&str>,
        _loader: Option<&str>,
    ) -> anyhow::Result<Vec<VersionInfo>> {
        // project_id is "owner/slug"
        let url = format!("https://hangar.papermc.io/api/v1/projects/{project_id}/versions");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let body: serde_json::Value = resp.json().await?;
        let result = body["result"].as_array().cloned().unwrap_or_default();

        let mut results = Vec::new();
        for v in result {
            let name = v["name"].as_str().unwrap_or_default().to_string();
            results.push(VersionInfo {
                id: name.clone(),
                name: name.clone(),
                version_number: name,
                game_versions: Vec::new(),
                loaders: vec!["paper".into()],
                download_url: String::new(), // resolved at install time via platform download
                filename: String::new(),
                size_bytes: 0,
                hashes: std::collections::HashMap::new(),
                release_type: "release".into(),
                dependencies: Vec::new(),
            });
        }

        Ok(results)
    }

    async fn get_project(&self, project_id: &str) -> anyhow::Result<ProjectSummary> {
        let url = format!("https://hangar.papermc.io/api/v1/projects/{project_id}");
        let resp = self.client.get(&url).send().await?.error_for_status()?;
        let p: serde_json::Value = resp.json().await?;

        Ok(ProjectSummary {
            id: project_id.to_string(),
            slug: p["namespace"]["slug"].as_str().unwrap_or_default().into(),
            name: p["name"].as_str().unwrap_or_default().into(),
            description: p["description"].as_str().unwrap_or_default().into(),
            author: p["namespace"]["owner"].as_str().unwrap_or_default().into(),
            icon_url: p["avatarUrl"].as_str().map(String::from),
            downloads: p["stats"]["downloads"].as_u64().unwrap_or(0),
            kind: ContentKind::Plugin,
            source: "hangar".into(),
            loaders: vec!["paper".into()],
            game_versions: Vec::new(),
        })
    }
}
