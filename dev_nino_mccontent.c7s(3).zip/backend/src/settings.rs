use garde::Validate;
use serde::{Deserialize, Serialize};
use shared::extensions::settings::{
    ExtensionSettings, SettingsDeserializeExt, SettingsDeserializer, SettingsSerializeExt,
    SettingsSerializer,
};
use utoipa::ToSchema;

/// Which external sources are enabled.
#[derive(ToSchema, Validate, Serialize, Deserialize, Clone, Default)]
pub struct ProviderSettings {
    #[garde(skip)]
    pub modrinth: bool,
    #[garde(skip)]
    pub curseforge: bool,
    #[garde(skip)]
    pub hangar: bool,
    #[garde(skip)]
    pub spigotmc: bool,
    /// Required when curseforge is enabled.
    #[garde(length(max = 128))]
    #[schema(max_length = 128)]
    pub curseforge_api_key: Option<String>,
}

/// A blacklist entry – either a project ID or a regex matched against the project name/slug.
#[derive(ToSchema, Validate, Serialize, Deserialize, Clone)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum BlacklistEntry {
    ProjectId {
        #[garde(length(chars, min = 1, max = 64))]
        #[schema(min_length = 1, max_length = 64)]
        id: String,
    },
    Regex {
        #[garde(length(chars, min = 1, max = 256))]
        #[schema(min_length = 1, max_length = 256)]
        pattern: String,
    },
}

/// Per-egg overrides (force loader, disable certain content types).
#[derive(ToSchema, Validate, Serialize, Deserialize, Clone)]
pub struct EggOverride {
    #[garde(skip)]
    pub egg_uuid: uuid::Uuid,
    /// If set, only this loader is considered for version filtering.
    #[garde(length(max = 32))]
    #[schema(max_length = 32)]
    pub force_loader: Option<String>,
    #[garde(skip)]
    pub allow_plugins: bool,
    #[garde(skip)]
    pub allow_mods: bool,
    #[garde(skip)]
    pub allow_modpacks: bool,
}

#[derive(ToSchema, Validate, Serialize, Deserialize, Clone)]
pub struct ExtensionSettingsData {
    #[garde(dive)]
    pub providers: ProviderSettings,

    /// Maximum download size in bytes (default 250 MiB).
    #[garde(range(min = 1_048_576, max = 1_073_741_824))]
    #[schema(minimum = 1048576, maximum = 1073741824)]
    pub max_download_bytes: u64,

    /// Regexes / project IDs that users may not install.
    #[garde(dive)]
    pub blacklist: Vec<BlacklistEntry>,

    /// Preferred loaders when none can be auto-detected.
    #[garde(length(max = 16))]
    pub default_loaders: Vec<String>,

    #[garde(dive)]
    pub egg_overrides: Vec<EggOverride>,
}

impl Default for ExtensionSettingsData {
    fn default() -> Self {
        Self {
            providers: ProviderSettings {
                modrinth: true,
                curseforge: false,
                hangar: true,
                spigotmc: true,
                curseforge_api_key: None,
            },
            max_download_bytes: 250 * 1024 * 1024,
            blacklist: Vec::new(),
            default_loaders: vec![
                "paper".into(),
                "fabric".into(),
                "forge".into(),
                "neoforge".into(),
            ],
            egg_overrides: Vec::new(),
        }
    }
}

#[async_trait::async_trait]
impl SettingsSerializeExt for ExtensionSettingsData {
    async fn serialize(
        &self,
        serializer: SettingsSerializer,
    ) -> Result<SettingsSerializer, anyhow::Error> {
        Ok(serializer
            .write_serde_setting("providers", &self.providers)?
            .write_serde_setting("max_download_bytes", &self.max_download_bytes)?
            .write_serde_setting("blacklist", &self.blacklist)?
            .write_serde_setting("default_loaders", &self.default_loaders)?
            .write_serde_setting("egg_overrides", &self.egg_overrides)?)
    }
}

pub struct ExtensionSettingsDataDeserializer;

#[async_trait::async_trait]
impl SettingsDeserializeExt for ExtensionSettingsDataDeserializer {
    async fn deserialize_boxed(
        &self,
        deserializer: SettingsDeserializer<'_>,
    ) -> Result<ExtensionSettings, anyhow::Error> {
        let defaults = ExtensionSettingsData::default();

        Ok(Box::new(ExtensionSettingsData {
            providers: deserializer
                .read_serde_setting("providers")
                .unwrap_or(defaults.providers),
            max_download_bytes: deserializer
                .read_serde_setting("max_download_bytes")
                .unwrap_or(defaults.max_download_bytes),
            blacklist: deserializer
                .read_serde_setting("blacklist")
                .unwrap_or(defaults.blacklist),
            default_loaders: deserializer
                .read_serde_setting("default_loaders")
                .unwrap_or(defaults.default_loaders),
            egg_overrides: deserializer
                .read_serde_setting("egg_overrides")
                .unwrap_or(defaults.egg_overrides),
        }))
    }
}
