use shared::State;
use utoipa_axum::{router::OpenApiRouter, routes};

mod get {
    use crate::{db::InstalledContent, model};
    use serde::Serialize;
    use shared::{
        ApiError, GetState,
        models::{server::GetServer, user::GetPermissionManager},
        response::{ApiResponse, ApiResponseResult},
    };
    use utoipa::ToSchema;

    #[derive(ToSchema, Serialize)]
    struct Response {
        items: Vec<InstalledContent>,
        limit: i32,
    }

    #[utoipa::path(get, path = "/", responses(
        (status = OK, body = inline(Response)),
        (status = UNAUTHORIZED, body = ApiError),
    ), params(
        (
            "server" = uuid::Uuid,
            description = "The server ID",
            example = "123e4567-e89b-12d3-a456-426614174000",
        ),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        server: GetServer,
    ) -> ApiResponseResult {
        permissions.has_server_permission("content.read")?;

        let items = InstalledContent::list_for_server(&state.database, server.uuid).await?;
        let limit = model::content_install_limit(&server)?;

        ApiResponse::new_serialized(Response { items, limit }).ok()
    }
}

mod search {
    use crate::{providers, settings::ExtensionSettingsData};
    use serde::{Deserialize, Serialize};
    use shared::{
        ApiError, GetState,
        models::{server::GetServer, user::GetPermissionManager},
        response::{ApiResponse, ApiResponseResult},
    };
    use utoipa::ToSchema;

    #[derive(Deserialize)]
    pub struct Query {
        pub q: String,
        pub kind: Option<String>,
        pub limit: Option<u32>,
    }

    #[derive(ToSchema, Serialize)]
    struct Response {
        results: Vec<providers::ProjectSummary>,
    }

    #[utoipa::path(get, path = "/search", responses(
        (status = OK, body = inline(Response)),
        (status = UNAUTHORIZED, body = ApiError),
    ), params(
        (
            "server" = uuid::Uuid,
            description = "The server ID",
            example = "123e4567-e89b-12d3-a456-426614174000",
        ),
    ))]
    pub async fn route(
        state: GetState,
        permissions: GetPermissionManager,
        _server: GetServer,
        axum::extract::Query(q): axum::extract::Query<Query>,
    ) -> ApiResponseResult {
        permissions.has_server_permission("content.install")?;

        let s = state.settings.get().await?;
        let settings = match s.find_extension_settings::<ExtensionSettingsData>() {
            Ok(ext) => ext.clone(),
            Err(_) => ExtensionSettingsData::default(),
        };

        let kind = match q.kind.as_deref() {
            Some("plugin") => providers::ContentKind::Plugin,
            Some("modpack") => providers::ContentKind::Modpack,
            _ => providers::ContentKind::Mod,
        };

        let providers_list = providers::build_enabled(&settings.providers);
        let limit = q.limit.unwrap_or(20).min(50);
        let mut results = Vec::new();

        for p in &providers_list {
            match p.search(&q.q, kind, None, None, limit).await {
                Ok(mut items) => results.append(&mut items),
                Err(err) => tracing::warn!(provider = p.name(), "search failed: {err:?}"),
            }
        }

        results.sort_by(|a, b| b.downloads.cmp(&a.downloads));
        results.truncate(limit as usize);

        ApiResponse::new_serialized(Response { results }).ok()
    }
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(get::route))
        .routes(routes!(search::route))
        .with_state(state.clone())
}
