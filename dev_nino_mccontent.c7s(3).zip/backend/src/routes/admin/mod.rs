use shared::State;
use utoipa_axum::{router::OpenApiRouter, routes};

mod get {
    use crate::db::InstalledContent;
    use serde::Serialize;
    use shared::{
        ApiError, GetState,
        models::user::GetPermissionManager,
        response::{ApiResponse, ApiResponseResult},
    };
    use utoipa::ToSchema;

    #[derive(ToSchema, Serialize)]
    struct Response {
        items: Vec<InstalledContent>,
    }

    #[utoipa::path(get, path = "/content", responses(
        (status = OK, body = inline(Response)),
        (status = UNAUTHORIZED, body = ApiError),
    ))]
    pub async fn route(state: GetState, permissions: GetPermissionManager) -> ApiResponseResult {
        permissions.has_admin_permission("content.read")?;

        let items = InstalledContent::list_all(&state.database, None, 100, 0).await?;

        ApiResponse::new_serialized(Response { items }).ok()
    }
}

mod settings_get {
    use crate::settings::ExtensionSettingsData;
    use serde::Serialize;
    use shared::{
        ApiError, GetState,
        models::user::GetPermissionManager,
        response::{ApiResponse, ApiResponseResult},
    };
    use utoipa::ToSchema;

    #[derive(ToSchema, Serialize)]
    struct Response {
        settings: ExtensionSettingsData,
    }

    #[utoipa::path(get, path = "/settings", responses(
        (status = OK, body = inline(Response)),
        (status = UNAUTHORIZED, body = ApiError),
    ))]
    pub async fn route(state: GetState, permissions: GetPermissionManager) -> ApiResponseResult {
        permissions.has_admin_permission("content.read")?;

        let settings = state.settings.get().await?;
        let extension = match settings.find_extension_settings::<ExtensionSettingsData>() {
            Ok(ext) => ext.clone(),
            Err(_) => ExtensionSettingsData::default(),
        };

        ApiResponse::new_serialized(Response {
            settings: extension,
        })
        .ok()
    }
}

pub fn router(state: &State) -> OpenApiRouter<State> {
    OpenApiRouter::new()
        .routes(routes!(get::route))
        .routes(routes!(settings_get::route))
        .with_state(state.clone())
}
