//! Shared install / update / remove logic.
use crate::{
    db::InstalledContent,
    providers::{ContentKind, ContentProvider, VersionInfo},
    settings::ExtensionSettingsData,
};
use axum::http::StatusCode;
use shared::{
    State,
    models::server::Server,
    response::DisplayError,
};

pub fn user_error(message: impl Into<String>, status: StatusCode) -> anyhow::Error {
    DisplayError::new(message.into()).with_status(status).into()
}

fn bad_request(message: impl Into<String>) -> anyhow::Error {
    user_error(message, StatusCode::BAD_REQUEST)
}

async fn settings(state: &State) -> Result<ExtensionSettingsData, anyhow::Error> {
    let s = state.settings.get().await?;
    match s.find_extension_settings::<ExtensionSettingsData>() {
        Ok(ext) => Ok(ext.clone()),
        Err(_) => Ok(ExtensionSettingsData::default()),
    }
}

pub async fn check_blacklist(
    settings: &ExtensionSettingsData,
    project_id: &str,
    name: &str,
) -> Result<(), anyhow::Error> {
    for entry in &settings.blacklist {
        match entry {
            crate::settings::BlacklistEntry::ProjectId { id } if id == project_id => {
                return Err(bad_request("this project is blacklisted by the administrator"));
            }
            crate::settings::BlacklistEntry::Regex { pattern } => {
                if let Ok(re) = regex::Regex::new(pattern) {
                    if re.is_match(name) {
                        return Err(bad_request(
                            "this project matches a blacklist rule and cannot be installed",
                        ));
                    }
                }
            }
            _ => {}
        }
    }
    Ok(())
}

pub async fn check_limit(state: &State, server: &Server) -> Result<(), anyhow::Error> {
    let limit = crate::model::content_install_limit(server).unwrap_or(0);
    if limit <= 0 {
        return Ok(()); // 0 = unlimited
    }
    let count = InstalledContent::count_for_server(&state.database, server.uuid).await?;
    if count >= limit as i64 {
        return Err(user_error(
            format!("server has reached its content install limit ({limit})"),
            StatusCode::FORBIDDEN,
        ));
    }
    Ok(())
}

pub fn target_dir(kind: ContentKind) -> &'static str {
    match kind {
        ContentKind::Plugin => "plugins",
        ContentKind::Mod | ContentKind::Modpack => "mods",
    }
}

pub async fn install(
    state: &State,
    server: &Server,
    provider: &dyn ContentProvider,
    project_id: &str,
    version: &VersionInfo,
    kind: ContentKind,
) -> Result<InstalledContent, anyhow::Error> {
    let settings = settings(state).await?;
    let project = provider.get_project(project_id).await?;

    check_blacklist(&settings, &project.id, &project.name).await?;
    check_limit(state, server).await?;

    if version.size_bytes > settings.max_download_bytes {
        return Err(bad_request("version exceeds the configured size limit"));
    }

    // Real implementation downloads and places the file via the panel file API.
    let dir = target_dir(kind);
    let dest = format!("{dir}/{}", version.filename);
    let size = version.size_bytes as i64;

    let kind_str = match kind {
        ContentKind::Plugin => "plugin",
        ContentKind::Mod => "mod",
        ContentKind::Modpack => "modpack",
    };

    let installed = InstalledContent::insert(
        &state.database,
        server.uuid,
        provider.name(),
        &project.id,
        &project.slug,
        &project.name,
        kind_str,
        &version.id,
        &version.version_number,
        &version.filename,
        &dest,
        size,
    )
    .await?;

    tracing::info!(
        server = %server.uuid,
        project = %project.name,
        version = %version.version_number,
        "installed content"
    );

    Ok(installed)
}

pub async fn remove(state: &State, content: &InstalledContent) -> Result<(), anyhow::Error> {
    InstalledContent::delete(&state.database, content.uuid).await?;
    tracing::info!(
        content = %content.uuid,
        file = %content.file_path,
        "removed content"
    );
    Ok(())
}
