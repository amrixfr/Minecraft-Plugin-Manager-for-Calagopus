# Minecraft Content Manager

A [Calagopus Panel](https://calagopus.com) extension that lets users search, install, update and remove
**Minecraft plugins**, **mods** and **modpacks** on their game servers.

Package name: `dev.nino.mccontent` · Requires panel `>=1.2.2` · Author: **nino**

## Features

- **Plugins** – search and install from Modrinth, Hangar (Paper/Spigot) and SpigotMC.
- **Mods** – search and install from Modrinth and CurseForge (Forge / Fabric / Quilt / NeoForge).
- **Modpacks** – install complete modpacks from Modrinth and CurseForge; the extension extracts
  the pack, places the correct loader and mods, and updates `server.properties` / start scripts
  when needed.
- **Version-aware** – automatically filters results by the server’s Minecraft version and
  detected loader (Vanilla, Paper, Purpur, Fabric, Forge, Quilt, NeoForge…).
- **One-click install** – downloads the correct file, places it in `plugins/` or `mods/`, and
  (for modpacks) applies the pack’s overrides.
- **Update checks** – shows available updates for installed content.
- **Safe removal** – removes the jar and any associated config folder if the user confirms.
- **Per-server limits** – `feature_limits.content_installs` controls how many items a server may
  have installed (editable in admin server forms).
- **Blacklist** – admins can block specific project IDs or name patterns.
- **Admin overview** – list every installed plugin/mod/modpack across the panel with search.
- **Audit log** – every install / update / remove is recorded.

## Installation

Download `dev_nino_mccontent.c7s.zip` from the
[latest release](https://github.com/nino/Minecraft-Content-Manager/releases/latest) and either upload it under **Admin → Extensions**
or drop it into your heavy image’s `build/extensions/` directory and `docker compose restart web`.
Extensions require the `:heavy` panel image (or a dev environment) — see the
[Calagopus docs](https://calagopus.com/docs/panel/extensions/installing-extensions).

## Configuration

**Admin → Extensions → Minecraft Content Manager → Configure**

- **Providers** – enable/disable Modrinth, CurseForge, Hangar, SpigotMC.
  - CurseForge requires an API key (free from console.curseforge.com).
  - SpigotMC / Hangar work without keys for public endpoints.
- **Default loaders** – preferred loaders when a server has none detected.
- **Blacklist** – project IDs or regexes that users may not install.
- **Max file size** – reject downloads larger than this (default 250 MiB).
- **Per-egg overrides** – force a specific loader or disable content types for certain eggs.

## API (once installed)

All routes are under the extension prefix. Authentication follows normal panel rules
(server ownership or admin).

- `GET  /content/search` – search plugins / mods / modpacks
- `GET  /content/{project}/versions` – list versions compatible with the server
- `POST /content/install` – install a specific version
- `POST /content/{uuid}/update` – update to latest compatible version
- `DELETE /content/{uuid}` – remove installed content
- `GET  /content` – list installed content for a server
- Admin equivalents under `/admin/content/…`

Full schemas appear in the panel’s OpenAPI document after installation.

## Roadmap

- Automatic dependency resolution for Fabric/Quilt mods.
- Scheduled update checks with optional auto-update.
- Support for Velocity / BungeeCord plugins.
- Import existing jars already present in the server filesystem.

## License

MIT
